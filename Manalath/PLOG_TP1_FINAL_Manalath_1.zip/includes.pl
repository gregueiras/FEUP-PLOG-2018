:- ensure_loaded(board).
:- ensure_loaded(neighbors).
:- ensure_loaded(player).
:- use_module(library(random)).
:- use_module(library(system)).